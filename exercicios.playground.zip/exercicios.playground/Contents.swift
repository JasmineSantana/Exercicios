//Ex1 = Informamos a variavel que está faltando no que é a Guard Let.
func login(with username: String?, password: String?) -> Bool {
   guard let username = username,
        let password = password else {
        return false
    }
    if username == "user1" && password == "123456" {
        return true
    } else {
        return false
    }
}
login(with: "user1", password: nil)


//EX2 = Nesse caso será o optional no Address, pois dentro da Struct o Adress já é um optional desta forma tudo que eu for acessar o

struct Person {
    let name: String
    var address: Address?
}
struct Address {
    let apartmentNumber: Int?
    var houseNumber: Int?
    var streetName: String
    var city: String
}
let person = Person(name: "Paulo")
let apartment = person.address?.apartmentNumber


//EX3 = Vai ser apresentado a opção initialized, pois ele nem acessou a funcionalidade e a função chama o State da enumeração não a variavel state.

enum State {
    case initialized
    case processing
    case processed
    case finished
}
var state = State.initialized
func transition(from oldState: State) {
    let state: State
    switch oldState {
    case .initialized:
        state = .processing
    case .processing:
        state = .processed
    case .processed:
        state = .finished
    case .finished:
        state = .finished
    }
}
transition(from: state)
print(state)


//Ex3 = Ele irá parar com 11;

//É uma array com 100 elementos, todos definidos como false
var unhatchedBirds = Array(repeating: false, count: 100)
//é um array vazio que irá armazenar os elementos
var hatchedBirds: [Bool] = []
//Contagem
for (index, bird) in unhatchedBirds.enumerated() {
    if index > 10 {
    break
    }
hatchedBirds.append (bird)
}
//Irá imprimir o numero de elementos no array
print(hatchedBirds.count)
